##  Responsive  bootstrap Landing page website 

![preview](images/scroll-eff.gif)

A landing page website developed using Bootstrap 4 ... for the help to the student's enhancing their skills.

** For Better Understanding, Have a look at this [article on medium ](https://medium.com/@hayanisaid1995/learn-bootstrap-4-in-30-minute-by-building-a-landing-page-website-guide-for-beginners-f64e03833f33) article...
Hope you like it :)
